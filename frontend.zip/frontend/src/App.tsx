import React from "react";

function App() {
  return <>Bonjour</>;
}

export default App;
